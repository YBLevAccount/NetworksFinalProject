import argparse
from PIL import Image, PngImagePlugin

def embed_strings_in_png(input_image_path, output_image_path, texts_to_embed):
    # Open the original image
    image = Image.open(input_image_path)
    
    # Create a new info dictionary and add each text to it with a unique key
    info = PngImagePlugin.PngInfo()
    for index, text in enumerate(texts_to_embed):
        key = f"hidden_text_{index}"
        info.add_text(key, text + " ")
    
    # Save the image with the new info dictionary
    image.save(output_image_path, "PNG", pnginfo=info)
    print(f"Texts successfully embedded into {output_image_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Embed hidden text strings into a PNG image.')
    parser.add_argument('input_image', help='The path to the input image file')
    parser.add_argument('output_image', help='The path to the output image file')
    parser.add_argument('hidden_texts', nargs='+', help='The hidden text strings to embed into the image')

    args = parser.parse_args()
    embed_strings_in_png(args.input_image, args.output_image, args.hidden_texts)
