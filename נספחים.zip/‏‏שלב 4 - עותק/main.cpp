#include "SHA256.h"
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "ws2_32.lib")
#define PORT 54000

using std::string;
using std::cout;

// hash of "Running#Reading"
string currect_hash = "a3ffe43fb62cee435bb623c2c81ac1d5ba70b9dafd684e8408bdf47b92a19d66";

void BindAndListen(SOCKET serverSocket);
SOCKET AcceptConnection(SOCKET serverSocket);
void ReceiveData(SOCKET clientSocket);
void Cleanup(SOCKET socket);

int main() {
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        std::cerr << "WSAStartup failed: " << result << std::endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Error at socket(): " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    BindAndListen(serverSocket);

    SOCKET clientSocket = AcceptConnection(serverSocket);
    while (1)
        ReceiveData(clientSocket);

    Cleanup(clientSocket);
    Cleanup(serverSocket);

    return 0;
}

void BindAndListen(SOCKET serverSocket) {
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed: " << WSAGetLastError() << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        exit(1);
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        std::cerr << "Listen failed: " << WSAGetLastError() << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        exit(1);
    }

    // Retrieve and print server IP and port
    sockaddr_in addr;
    int addrLen = sizeof(addr);
    getsockname(serverSocket, (sockaddr*)&addr, &addrLen);

    char ipStr[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &addr.sin_addr, ipStr, INET_ADDRSTRLEN);
    std::cout << "Server IP: " << ipStr << std::endl;
    std::cout << "Server Port: " << ntohs(addr.sin_port) << std::endl;
}

SOCKET AcceptConnection(SOCKET serverSocket) {
    sockaddr_in clientAddr;
    int clientSize = sizeof(clientAddr);

    SOCKET clientSocket = accept(serverSocket, (sockaddr*)&clientAddr, &clientSize);
    if (clientSocket == INVALID_SOCKET) {
        std::cerr << "Accept failed: " << WSAGetLastError() << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        exit(1);
    }

    char host[NI_MAXHOST];
    char service[NI_MAXSERV];

    ZeroMemory(host, NI_MAXHOST);
    ZeroMemory(service, NI_MAXSERV);

    if (getnameinfo((sockaddr*)&clientAddr, sizeof(clientAddr), host, NI_MAXHOST, service, NI_MAXSERV, 0) == 0) {
        std::cout << "Connected on " << host << " on port " << service << std::endl;
    }
    else {
        inet_ntop(AF_INET, &clientAddr.sin_addr, host, NI_MAXHOST);
        std::cout << "Connected on " << host << " on port " << ntohs(clientAddr.sin_port) << std::endl;
    }

    return clientSocket;
}

void ReceiveData(SOCKET clientSocket) {
    char buf[4096];
    ZeroMemory(buf, 4096);

    int bytesReceived = recv(clientSocket, buf, 4096, 0);
    if (bytesReceived > 0) {
        string msg = std::string(buf, 0, bytesReceived);
        cout << msg << '\t' << msg.size() << '\n';
        string msg_hash = sha256(msg);
        if (msg_hash == currect_hash)
            MessageBoxA(0, buf, "Remove the 8th letter", MB_OK);
        else
        {
            char response[256] = "try again";
            send(clientSocket, response, strlen(response) + 1, 0);
        }
    }
}

void Cleanup(SOCKET socket) {
    closesocket(socket);
    WSACleanup();
}
