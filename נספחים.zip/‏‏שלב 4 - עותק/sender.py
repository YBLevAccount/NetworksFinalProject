import socket

HOST = "127.0.0.1"  # The server's hostname or IP address
PORT = 54000  # The port used by the server

hobbies =   ["Painting", "Chess", "Running", "Fishing", "Gardening",
            "Photography", "Reading", "Cooking", "Traveling", "Hiking",
            "Baking", "Video Gaming", "Yoga", "Woodworking", "Drawing",
            "Cycling", "Playing Guitar", "Photography", "Soccer", "Writing",
            "Playing Piano", "Cooking", "Dancing", "Reading", "Hiking", "Chess"]

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))
msg = ""
while True:
    for i in hobbies:
        for j in hobbies:
            msg = i + "#" + j
            sock.send(msg.encode("ASCII"))
            res = sock.recv(1024).decode("ASCII")
            print(res) 
sock.close()