#!/usr/bin/env python3
# to run from user side use /check?password=xxx

import cgi
import time
import os

# Get the password from the query string
form = cgi.FieldStorage()
input_password = form.getvalue("password", "")

# Function to check password with timing delay
def check_password(input_password):
    with open("/home/ksbspunh/domains/lellnotdell.freewebhostmost.com/public_html/classified_html/password.txt", "r") as file:
        for i in input_password:
            j = file.read(1)
            if j != i:
                return False
        return (file.read(1) == "") # there are no more characters in the password
    return False # if file does not exist

# Response
if check_password(input_password):
    # If the password is correct, serve the correct.html file
    with open("/home/ksbspunh/domains/lellnotdell.freewebhostmost.com/public_html/classified_html/correct.html", "r") as file:
        print("Content-Type: text/html\n")
        print(file.read())
else:
    # If the password is incorrect, return a 403 Forbidden status
    time.sleep(1) # prevent BrutForce attack
    print("Status: 403 Forbidden\n")