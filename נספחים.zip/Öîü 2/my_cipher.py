import argparse
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
import os

def encrypt_file(file_path, password):
    # Generate a random salt
    salt = os.urandom(16)

    # Derive a key from the password
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password.encode())

    # Generate a random initialization vector
    iv = os.urandom(16)

    # Read the file data
    with open(file_path, 'rb') as f:
        file_data = f.read()

    # Pad the data
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(file_data) + padder.finalize()

    # Encrypt the data
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    # Write the salt, IV, and encrypted data to a new file
    with open(file_path + '.enc', 'wb') as f:
        f.write(salt + iv + encrypted_data)

    print(f"File '{file_path}' has been encrypted and saved as '{file_path}.enc'")
    
def decrypt_file(encrypted_file_path, password):
    # Read the encrypted file data
    with open(encrypted_file_path, 'rb') as f:
        salt = f.read(16)  # First 16 bytes are the salt
        iv = f.read(16)    # Next 16 bytes are the IV
        encrypted_data = f.read()  # The rest is the encrypted data

    # Derive the key from the password and salt
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password.encode())

    # Decrypt the data
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_padded_data = decryptor.update(encrypted_data) + decryptor.finalize()

    # Unpad the data
    unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
    decrypted_data = unpadder.update(decrypted_padded_data) + unpadder.finalize()

    # Write the decrypted data to a new file
    decrypted_file_path = encrypted_file_path.replace('.enc', '.dec')
    with open(decrypted_file_path, 'wb') as f:
        f.write(decrypted_data)

    print(f"File '{encrypted_file_path}' has been decrypted and saved as '{decrypted_file_path}'")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Encrypt or decrypt a file using AES.")
    parser.add_argument("action", choices=["encrypt", "decrypt"], help="Action to perform: encrypt or decrypt")
    parser.add_argument("file_path", help="Path to the file to encrypt/decrypt")
    parser.add_argument("password", help="Password for encryption/decryption")

    args = parser.parse_args()

    if args.action == "encrypt":
        encrypt_file(args.file_path, args.password)
    elif args.action == "decrypt":
        decrypt_file(args.file_path, args.password)
